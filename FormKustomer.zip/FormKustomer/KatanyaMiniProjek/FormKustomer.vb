﻿Imports System
Imports System.Data
Imports System.Data.SqlClient

Public Class FormKustomer

    Dim conn As SqlConnection = New SqlConnection("Data Source = LAPTOP-BBM04TAS\SQLEXPRESS;" & "user id = userol; password = 123456; Integrated Security = True; " & "database = ApotekSehat")
    Dim ADP As SqlDataAdapter
    Dim DS As New DataSet

    Private Sub FormKustomer_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ViewTable()
        aturDGV()
    End Sub

    Sub ViewTable()
        ADP = New SqlDataAdapter("Select * From data_kustomer", conn)
        DS = New DataSet
        ADP.Fill(DS, "DataBarang")
        dgvDataKustomer.DataSource = DS.Tables("DataBarang")
    End Sub

    Sub Clear()
        tbIdKustomer.Text = ""
        tbNamaKustomer.Text = ""
        tbNoHpKustomer.Text = ""
        cbJenisKelamin.Text = ""
        tbAlamatKustomer.Text = ""
        tbSearchKustomer.Text = ""
    End Sub

    Sub aturDGV()
        dgvDataKustomer.Columns("id_kustomer").Width = 100
        dgvDataKustomer.Columns("nama").Width = 180
        dgvDataKustomer.Columns("no_hp").Width = 120
        dgvDataKustomer.Columns("jenis_kelamin").Width = 100
        dgvDataKustomer.Columns("alamat").Width = 170
    End Sub


    '----------- BUTTON SIMPAN ----------

    Private Sub btCreateKustomer_Click(sender As Object, e As EventArgs) Handles btCreateKustomer.Click
        Dim cmd As New SqlCommand("select count(*) from data_kustomer where id_kustomer = @id_kustomer", conn)
        cmd.Parameters.AddWithValue("@id_kustomer", tbIdKustomer.Text)
        conn.Open()
        Dim count As Integer = CInt(cmd.ExecuteScalar())
        conn.Close()


        If tbIdKustomer.Text = "" Or tbNamaKustomer.Text = "" Or tbNoHpKustomer.Text = "" Or cbJenisKelamin.Text = "" Or tbAlamatKustomer.Text = "" Then
            MessageBox.Show("Data belum lengkap!")

        Else

            If count > 0 Then
                MessageBox.Show("ID kustomer sudah digunakan sebelumnya")

            Else
                Dim sqlins As String = "insert into data_kustomer (id_kustomer, nama, no_hp, jenis_kelamin, alamat)" &
                "values (@id_kustomer, @nama, @no_hp, @jenis_kelamin, @alamat)"

                Try
                    conn.Open()
                    MsgBox("Data kustomer berhasil disimpan")
                    Dim cmdInsert As SqlCommand = New SqlCommand(sqlins, conn)
                    cmdInsert.Parameters.AddWithValue("@id_kustomer", tbIdKustomer.Text)
                    cmdInsert.Parameters.AddWithValue("@nama", tbNamaKustomer.Text)
                    cmdInsert.Parameters.AddWithValue("@no_hp", tbNoHpKustomer.Text)
                    cmdInsert.Parameters.AddWithValue("@jenis_kelamin", cbJenisKelamin.Text)
                    cmdInsert.Parameters.AddWithValue("@alamat", tbAlamatKustomer.Text)
                    cmdInsert.ExecuteNonQuery()
                    ViewTable()

                Catch ex As Exception
                    MsgBox(ex.ToString)
                Finally
                    conn.Close()
                    'MsgBox("Connection Closed")
                    Clear()
                End Try
            End If
        End If
    End Sub

    '----------- BUTTON UPDATE -----------

    Private Sub btUpdateKustomer_Click(sender As Object, e As EventArgs) Handles btUpdateKustomer.Click
        Dim cmd As New SqlCommand

        If tbIdKustomer.Text = "" Or tbNamaKustomer.Text = "" Or tbNoHpKustomer.Text = "" Or cbJenisKelamin.Text = "" Or tbAlamatKustomer.Text = "" Then
            MessageBox.Show("Data Belum Lengkap!")

        Else
            Try
                conn.Open()
                cmd.Connection = conn
                cmd.CommandType = CommandType.Text
                cmd.CommandText = "UPDATE data_kustomer SET nama = @nama, no_hp = @no_hp, jenis_kelamin = @jenis_kelamin, alamat = @alamat  WHERE id_kustomer = @id_kustomer"
                cmd.Parameters.AddWithValue("@id_kustomer", tbIdKustomer.Text)
                cmd.Parameters.AddWithValue("@nama", tbNamaKustomer.Text)
                cmd.Parameters.AddWithValue("@no_hp", tbNoHpKustomer.Text)
                cmd.Parameters.AddWithValue("@jenis_kelamin", cbJenisKelamin.Text)
                cmd.Parameters.AddWithValue("@alamat", tbAlamatKustomer.Text)

                cmd.ExecuteNonQuery()
                ViewTable()
                MsgBox("Data kustomer berhasil diupdate!")
            Catch ex As Exception
                MsgBox(ex.ToString)
            Finally
                conn.Close()
                Clear()
            End Try
        End If
    End Sub


    '----------- BUTTON DELETE ------------

    Private Sub btDeleteKustomer_Click(sender As Object, e As EventArgs) Handles btDeleteKustomer.Click
        If tbIdKustomer.Text = "" Then
            MsgBox("Data kustomer tidak ditemukan")
            Exit Sub
        Else
            If MessageBox.Show("Anda yakin ingin menghapus data kustomer?", "Konfirmasi", MessageBoxButtons.YesNo) = Windows.Forms.DialogResult.Yes Then
                conn.Open()
                Dim sqlins As String = "Delete data_kustomer where id_kustomer ='" & tbIdKustomer.Text & "'"
                Dim cmdInsert As SqlCommand = New SqlCommand(sqlins, conn)
                cmdInsert.ExecuteNonQuery()
                MsgBox("Data kustomer telah dihapus")
                ViewTable()

            Else
                MsgBox("Data kustomer tidak jadi dihapus.")
            End If

        End If
        conn.Close()
        Clear()
    End Sub

    '----------- BUTTON SEARCH ------------

    Private Sub btSearchKustomer_Click(sender As Object, e As EventArgs) Handles btSearchKustomer.Click
        conn.Open()
        Dim query As String = "select * from data_kustomer where id_kustomer LIKE '%" & tbSearchKustomer.Text & "%' 
                                or nama LIKE '%" & tbSearchKustomer.Text & "%' 
                                or jenis_kelamin LIKE '%" & tbSearchKustomer.Text & "%' 
                                or alamat LIKE '%" & tbSearchKustomer.Text & "%'"
        Dim DA As New SqlDataAdapter(query, conn)
        Dim DT As New DataTable()
        DA.Fill(DT)
        dgvDataKustomer.DataSource = DT

        If DT.Rows.Count > 0 Then
            MessageBox.Show("Data kustomer ditemukan")
        Else
            MessageBox.Show("Data kustomer tidak ditemukan")
        End If
        conn.Close()
        Clear()
    End Sub

    '----------- BUTTON CLEAR ------------

    Private Sub btClearKustomer_Click(sender As Object, e As EventArgs) Handles btClearKustomer.Click
        conn.Open()
        Dim query As String = "select * from data_kustomer"
        Dim DA As New SqlDataAdapter(query, conn)
        Dim DT As New DataTable()
        DA.Fill(DT)
        dgvDataKustomer.DataSource = DT
        conn.Close()
        Clear()
    End Sub


    '----------- DATA SUPPLIER ------------
    Private Sub dgvDataKustomer_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles dgvDataKustomer.CellContentClick
        Dim selectRow As DataGridViewRow = dgvDataKustomer.Rows(e.RowIndex)

        tbIdKustomer.Text = selectRow.Cells("id_kustomer").Value.ToString()
        tbNamaKustomer.Text = selectRow.Cells("nama").Value.ToString()
        tbNoHpKustomer.Text = selectRow.Cells("no_hp").Value.ToString()
        cbJenisKelamin.Text = selectRow.Cells("jenis_kelamin").Value.ToString()
        tbAlamatKustomer.Text = selectRow.Cells("alamat").Value.ToString()
    End Sub


    '----------- MENAMPILKAN DATA DENGAN MENGINPUTKAN ID DI TEXTBOX ------------

    Private Sub tbIdKustomer_TextChanged(sender As Object, e As EventArgs) Handles tbIdKustomer.TextChanged
        Try
            conn.Open()

            Dim query As New SqlCommand("select * From data_kustomer where id_kustomer = @id_kustomer", conn)
            query.Parameters.AddWithValue("@id_kustomer", tbIdKustomer.Text)
            Dim DR As SqlDataReader = query.ExecuteReader()


            If DR.Read() Then
                tbNamaKustomer.Text = DR("nama").ToString()
                tbNoHpKustomer.Text = DR("no_hp").ToString()
                cbJenisKelamin.Text = DR("jenis_kelamin").ToString()
                tbAlamatKustomer.Text = DR("alamat").ToString()

            Else
                tbNamaKustomer.Text = ""
                tbNoHpKustomer.Text = ""
                cbJenisKelamin.Text = ""
                tbAlamatKustomer.Text = ""
            End If
            DR.Close()

        Catch ex As Exception
            MessageBox.Show("Terjadi kesalahan: " & ex.Message)
        Finally
            conn.Close()
        End Try
    End Sub



    Private Sub ExitToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ExitToolStripMenuItem.Click
        If MessageBox.Show("Anda yakin ingin menutup aplikasi ini?", "Konfirmasi", MessageBoxButtons.YesNo) = Windows.Forms.DialogResult.Yes Then
            End
        End If
    End Sub


End Class